/* 
 * File:   main.cpp
 * Author: Mark Acevedo
 * Created on September 13, 2017, 10:05 PM
 * Purpose: Creating a diamond problem 16
 */

//System Libraries
#include <iostream>     //Input/Output Stream Library
using namespace std;    //Standard Name-space under which System Libraries reside
//Execution Begins Here!
int main(int argc, char** argv) {
 //Create a program that generates a diamond when ran 
    cout << "   *  " << endl;
    cout << "  *** " << endl;
    cout << " ***** " << endl;
    cout << "*******" << endl;
    cout << " ***** " << endl;
    cout << "  ***  " << endl;
    cout << "   *  " << endl;
    //Exit the program
    return 0;
}